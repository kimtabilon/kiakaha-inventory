@if(Session::has('message'))
<div class="pad no-print message-alert">
    <div class="callout alert alert-{{ Session::get('message.type') }}" style="margin-bottom: 0!important;">
        @if(Session::has('message.title'))
        <h4><i class="icon fa fa-{{ Session::get('message.icon') }}"></i> {{ Session::get('message.title') }}</h4>
        @endif
        {{ Session::get('message.text') }}
    </div>
</div>
@endif