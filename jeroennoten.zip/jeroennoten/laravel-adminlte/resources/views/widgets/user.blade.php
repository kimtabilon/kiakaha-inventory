<!-- User Account: style can be found in dropdown.less -->
<li class="dropdown user user-menu">
  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
    <img src="{{ asset('vendor/adminlte/dist/img/user1-128x128.jpg') }}" class="user-image" alt="User Image">
    <span class="hidden-xs">{{ Auth::user()->name }}</span>
  </a>
  <ul class="dropdown-menu">
    <!-- User image -->
    <li class="user-header">
      <img src="{{ asset('vendor/adminlte/dist/img/user1-128x128.jpg') }}" class="img-circle" alt="User Image">
      <p>
        {{ Auth::user()->name }}
        <small>{{Auth::user()->role->name}}</small>
      </p>
    </li>
    <!-- Menu Body -->
    <!-- <li class="user-body">
      <div class="col-xs-4 text-center">
        <a href="users" target="_self">Users</a>
      </div>
      <div class="col-xs-4 text-center">
        <a href="donors" target="_self">Donors</a>
      </div>
      <div class="col-xs-4 text-center">
        <a href="reports" target="_self">Reports</a>
      </div>
    </li> -->
    <!-- Menu Footer-->
    <li class="user-footer">
      <div class="pull-left">
        <a href="profile" target="_self" class="btn btn-default btn-flat"><i class="fa fa-fw fa-user"></i> Profile</a>
      </div>
      <div class="pull-right">
      @if(config('adminlte.logout_method') == 'GET' || !config('adminlte.logout_method') && version_compare(\Illuminate\Foundation\Application::VERSION, '5.3.0', '<'))
          <a href="{{ url(config('adminlte.logout_url', 'auth/logout')) }}" class="btn btn-default btn-flat">
              <i class="fa fa-fw fa-power-off"></i> Logout
          </a>
      @else
          <a href="#" class="btn btn-default btn-flat"
             onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
          >
              <i class="fa fa-fw fa-power-off"></i> Logout
          </a>
          <form id="logout-form" action="{{ url(config('adminlte.logout_url', 'auth/logout')) }}" method="POST" style="display: none;">
              @if(config('adminlte.logout_method'))
                  {{ method_field(config('adminlte.logout_method')) }}
              @endif
              {{ csrf_field() }}
          </form>
      @endif
      </div>
    </li>
  </ul>
</li>